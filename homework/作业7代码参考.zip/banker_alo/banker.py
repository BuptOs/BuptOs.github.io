# @Sylvan Ding 2022.05.31


import numpy as np

finished = set()

def valid_check(P, Request, Need):
    if np.sum(Request > Need[P, :]):
        print("\033[0;31mERROR!P{} REQUEST EXCEEDS ITS NEED!\033[0m".format(P))
        return False
    print("\033[0;32mVALID CHECK PASSED!\033[0m")
    return True


def resource_check(Request, Available):
    if np.sum(Request > Available):
        print("\033[0;31mREQUEST EXCEEDS AVAILABLE!\033[0m")
        return False
    else:
        print("\033[0;32mRESOURCE CHECK PASSED!\033[0m")
        return True


def safe_check(Work, Need, Allocation, n):
    finished = np.sum(np.all(Need == 0, axis=1) & np.all(Allocation == 0, axis=1))
    print("Number of processes with both Need and Allocation as 0: {}".format(finished))
    Q = []
    while True:
        i = 0
        while i < n:
            if i not in Q and not np.sum(Need[i, :] > Work) and not (np.all(Need[i, :] == 0) and np.all(Allocation[i, :] == 0)):
                Q.append(i)
                temp = Work.copy()
                Work = Work + Allocation[i, :]
                print_safe_check(i, temp, Need, Allocation, Work)
                break
            i = i + 1
        if i == n:
            break
    if len(Q) < n - finished:
        print("\033[0;31mSAFE CHECK FAILED!\033[0m")
        return False
    else:
        print("\033[0;32mSAFE CHECK PASSED!\nSecured Sequence is {}.\033[0m".format(Q))
        return True


def try_allocate(Available, Allocation, Need, Request, P):
    Available = Available - Request
    Allocation[P, :] = Allocation[P, :] + Request
    Need[P, :] = Need[P, :] - Request
    return Available, Need, Allocation


def print_safe_check(k, Work, Need, Allocation, Work_Allocation):
    print("{}\t {}\t {}\t {}\t {}".format(k,
                                          Work,
                                          Need[k, :],
                                          Allocation[k, :],
                                          Work_Allocation))


def print_resource(Available, Need, Allocation, n):
    print("Current resource information: ")
    print("Available: {}".format(Available))
    print("P\t Allocation\t Need")
    for i in range(n):
        print("{}\t {}\t {}".format(i, Allocation[i, :], Need[i, :]))


def print_request_info(P, Request):
    print("\033[0;33mP{} requests {}.\033[0m".format(P, Request))


def Banker(n, Available, Max, Allocation, P, Request):
    """
    :param n: int
    :param Available: array[n][m]
    :param Max: array[n][m]
    :param Allocation: array[n][m]
    :param P: index of process to request
    :param Request: array[m]
    :return: Available, Need, Allocation
    """
    global finished
    print_request_info(P, Request)
    Available = np.asarray(Available)
    Max = np.asarray(Max)
    Allocation = np.asarray(Allocation)
    Request = np.asarray(Request)
    Need = Max - Allocation
    print_resource(Available, Need, Allocation, n)
    if (valid_check(P, Request, Need) and resource_check(Request, Available) and
            safe_check(*try_allocate(Available.copy(),
                                     Allocation.copy(),
                                     Need.copy(),
                                     Request, P), n)):
        Available, Need, Allocation = try_allocate(Available.copy(),
                                                   Allocation.copy(),
                                                   Need.copy(),
                                                   Request, P)
        # 如果有进程的Need全是0，将该进程的Allocation加到Available里面,并将Allocation置0
        for i in range(n):
            if np.all(Need[i, :] == 0):
                Available = Available + Allocation[i, :]
                Allocation[i, :] = 0
                Max[i, :] = 0
                finished.add(i)
        
        print("Finished process: {}".format(finished))
        print_resource(Available, Need, Allocation, n)
    return Available, Max, Allocation


def BankerAlgorithm(N, M, R, T, S):
    """
    :param N: task number N
    :param M: resource type number M
    :param R: resource amount for each type. R[M]
    :param T: MAX resource for each task <Ti,j> where i=1-N and j=1-M. T[N][M]
    :param S: Sequence of resource request. S[req_index] = [tasknumber, request=[M]]
    """
    n = N
    m = M
    Available = R
    Max = T
    Allocation = np.zeros((n, m))
    global finished

    for s in S:
        P = s[0]
        Request = s[1]
        Available, Max, Allocation = Banker(n, Available, Max, Allocation, P, Request)
        if len(finished) == n:
            print("\033[0;32mAll processes are finished!\033[0m")
            break


if __name__ == '__main__':
    N = int(input("Enter the number of tasks (N): "))
    M = int(input("Enter the number of resource types (M): "))
    R = list(map(int, input("Enter the number of resources for each type (R): ").split()))
    assert len(R) == M, "The number of resources for each type should be equal to M."
    T = []
    for i in range(N):
        T.append(list(map(int, input("Enter the MAX resources for task {} (T): ".format(i)).split())))

    S = []
    while True:
        s = input("Enter the sequence of resource request (tasknumber, request): ").split(" ", 1)
        if s[0] == '':
            break
        else:
            S.append([int(s[0]), list(map(int, s[1].split()))])
    BankerAlgorithm(N, M, R, T, S)
