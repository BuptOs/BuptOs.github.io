import random

def all_random():
    strs = []

    N = random.randint(4, 8)
    M = random.randint(3, 6)
    R = [random.randint(1, 10) for _ in range(M)]
    T = [[random.randint(0, R[i]) for i in range(M)] for _ in range(N)]
    seq_len = random.randint(10, 20)
    S = []
    for _ in range(seq_len):
        for i in range(M):
            ps = random.randint(0, N-1)
            request = [random.randint(0, min(R[i], T[ps][i])) for i in range(M)]
            S.append([ps, request])

    strs.append(str(N))
    strs.append(str(M))
    strs.append(' '.join(map(str, R)))
    for i in range(N):
        strs.append(' '.join(map(str, T[i])))

    for s in S:
        strs.append(str(s[0]) + ' ' + ' '.join(map(str, s[1])))

    with open("random.in", "w") as f:
        f.write('\n'.join(strs))
        f.write('\n\n')


def pass_random():
    strs = []

    N = random.randint(4, 8)
    M = random.randint(3, 6)
    R = [random.randint(1, 20) for _ in range(M)]
    T = [[random.randint(0, R[i] // N) for i in range(M)] for _ in range(N)]
    seq_len = random.randint(20, 50)
    S = []
    for _ in range(seq_len):
        for i in range(M):
            ps = random.randint(0, N-1)
            request = [random.randint(0, min(R[i], T[ps][i])) for i in range(M)]
            S.append([ps, request])

    strs.append(str(N))
    strs.append(str(M))
    strs.append(' '.join(map(str, R)))
    for i in range(N):
        strs.append(' '.join(map(str, T[i])))

    for s in S:
        strs.append(str(s[0]) + ' ' + ' '.join(map(str, s[1])))

    with open("passrandom.in", "w") as f:
        f.write('\n'.join(strs))
        f.write('\n\n')

if __name__ == "__main__":
    all_random()
    pass_random()