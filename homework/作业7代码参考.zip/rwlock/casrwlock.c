#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <unistd.h>
#include <pthread.h>

#define WRITE_LOCK 0x80000000  // 写锁标志位（高位）
#define READ_MASK  0x7FFFFFFF  // 读锁计数掩码（低位）

typedef struct {
    atomic_int state;  // 使用一个原子变量表示锁的状态
} RWLock;

// 初始化 RWLock
void RWLock_init(RWLock *rwlock) {
    atomic_store(&rwlock->state, 0);
}

// 获取读锁
void RWLock_startRead(RWLock *rwlock) {
    while (1) {
        int current = atomic_load(&rwlock->state);
        if (current & WRITE_LOCK) {  // 如果写锁被占用，则自旋
            sched_yield();  // 让出 CPU
            continue;
        }
        // 尝试增加读锁计数
        if (atomic_compare_exchange_weak(&rwlock->state, &current, current + 1)) {
            break;
        }
    }
}

// 释放读锁
void RWLock_doneRead(RWLock *rwlock) {
    atomic_fetch_sub(&rwlock->state, 1);  // 减少读锁计数
}

// 获取写锁
void RWLock_startWrite(RWLock *rwlock) {
    while (1) {
        int current = atomic_load(&rwlock->state);
        if (current != 0) {  // 如果有读锁或写锁被占用，则自旋
            sched_yield();
            continue;
        }
        // 尝试设置写锁（高位）
        if (atomic_compare_exchange_weak(&rwlock->state, &current, WRITE_LOCK)) {
            break;
        }
    }
}

// 释放写锁
void RWLock_doneWrite(RWLock *rwlock) {
    atomic_store(&rwlock->state, 0);  // 释放写锁
}

RWLock rwlock;  // 全局读写锁
int shared_resource = 0;  // 共享资源

void *reader(void *arg) {
    int id = *(int *)arg;
    for (int i = 0; i < 5; ++i) {
        RWLock_startRead(&rwlock);
        printf("Reader %d is reading. Shared value: %d\n", id, shared_resource);
        usleep(100000);  // 模拟读操作耗时
        RWLock_doneRead(&rwlock);
        usleep(50000);  // 模拟其他操作耗时
    }
    return NULL;
}

void *writer(void *arg) {
    int id = *(int *)arg;
    for (int i = 0; i < 5; ++i) {
        RWLock_startWrite(&rwlock);
        shared_resource += 1;
        printf("Writer %d is writing. New shared value: %d\n", id, shared_resource);
        usleep(150000);  // 模拟写操作耗时
        RWLock_doneWrite(&rwlock);
        usleep(50000);  // 模拟其他操作耗时
    }
    return NULL;
}

int main() {
    RWLock_init(&rwlock);

    pthread_t readers[5];
    pthread_t writers[2];
    int reader_ids[5] = {0, 1, 2, 3, 4};
    int writer_ids[2] = {0, 1};

    // 创建读者线程
    for (int i = 0; i < 5; ++i) {
        pthread_create(&readers[i], NULL, reader, &reader_ids[i]);
    }

    // 创建写者线程
    for (int i = 0; i < 2; ++i) {
        pthread_create(&writers[i], NULL, writer, &writer_ids[i]);
    }

    // 等待所有线程完成
    for (int i = 0; i < 5; ++i) {
        pthread_join(readers[i], NULL);
    }
    for (int i = 0; i < 2; ++i) {
        pthread_join(writers[i], NULL);
    }

    printf("Final shared resource value: %d\n", shared_resource);

    return 0;
}

