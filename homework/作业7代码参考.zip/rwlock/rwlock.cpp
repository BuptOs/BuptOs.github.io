#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <atomic>
#include <random>
#include <mutex>
#include <condition_variable>

class RWLock {
private:
    std::mutex lock;  // 保护共享资源的锁
    std::condition_variable cond;  // 单一条件变量

    int AR = 0;  // 正在读取的线程数
    int AW = 0;  // 正在等待写的线程数
    int WR = 0;  // 正在写的线程数
    int WW = 0;  // 正在等待读的线程数

public:
    void startRead() {
        std::unique_lock<std::mutex> ulock(lock);
        WR++;
        while (AW > 0 || WW > 0) {
            cond.wait(ulock);
        }
        WR--;
        AR++;
    }

    void doneRead() {
        std::unique_lock<std::mutex> ulock(lock);
        AR--;
        if (AR == 0 && WW > 0) {
            cond.notify_all();
        }
    }

    void startWrite() {
        std::unique_lock<std::mutex> ulock(lock);
        WW++;
        while (AR > 0 || AW > 0) {
            cond.wait(ulock);
        }
        WW--;
        AW++;
    }

    void doneWrite() {
        std::unique_lock<std::mutex> ulock(lock);
        AW--;
        if (WW > 0) {
            cond.notify_one();
        } else {
            cond.notify_all();
        }
    }
};

// 共享资源
int shared_resource = 0;
std::atomic<int> read_count(0);  // 用于验证读取操作
std::atomic<int> write_count(0); // 用于验证写入操作

void reader(RWLock &rwlock, int id) {
    rwlock.startRead();
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    ++read_count;
    rwlock.doneRead();
}

void writer(RWLock &rwlock, int id) {
    rwlock.startWrite();
    shared_resource += 1;
    ++write_count;
    std::this_thread::sleep_for(std::chrono::milliseconds(150));
    rwlock.doneWrite();
}

int main() {
    RWLock rwlock;

    // 创建多个读者线程和写者线程
    std::vector<std::thread> threads;

    // 启动5个读者线程
    for (int i = 0; i < 10; ++i) {
        threads.emplace_back(reader, std::ref(rwlock), i);
    }

    // 启动2个写者线程
    for (int i = 0; i < 4; ++i) {
        threads.emplace_back(writer, std::ref(rwlock), i);
    }

    // 等待所有线程完成
    for (auto &t : threads) {
        t.join();
    }

    // 输出最终结果
    std::cout << "Final shared resource value: " << shared_resource << "\n";
    std::cout << "Total read operations: " << read_count.load() << "\n";
    std::cout << "Total write operations: " << write_count.load() << "\n";

    return 0;
}


