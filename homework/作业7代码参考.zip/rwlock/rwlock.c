#include <pthread.h>
#include <stdatomic.h>
#include <unistd.h>
#include <stdio.h>

typedef struct RWlock {
    pthread_mutex_t lock;
    pthread_cond_t cond;
    int AR, AW, WR, WW;
}RWLock;

void RWLock_init(RWLock* l) {
    pthread_mutex_init(&l->lock, NULL);
    pthread_cond_init(&l->cond, NULL);
    l->AR = l->AW = l->WR = l->WW = 0;
}

void RWLock_startread(RWLock* l) {
    pthread_mutex_lock(&l->lock);
    l->WR ++;
    while(l->WW > 0 || l->AW > 0) {
        pthread_cond_wait(&l->cond, &l->lock);
    }
    l->WR--;
    l->AR++;
    pthread_mutex_unlock(&l->lock);
}

void RWLock_doneread(RWLock* l) {
    pthread_mutex_lock(&l->lock);
    l->AR--;
    if(l->AR==0 || l->WW > 0)
        pthread_cond_signal(&l->cond);
    pthread_mutex_unlock(&l->lock);
}

void RWLock_startwrite(RWLock* l) {
    pthread_mutex_lock(&l->lock);
    l->WW ++;
    while(l->AW > 0) {
        pthread_cond_wait(&l->cond, &l->lock);
    }
    l->WW--;
    l->AW++;
    pthread_mutex_unlock(&l->lock);
}

void RWLock_donewrite(RWLock* l) {
    pthread_mutex_lock(&l->lock);
    l->AW--;
    if(l->WW > 0) {
        pthread_cond_signal(&l->cond);
    } else {
        pthread_cond_broadcast(&l->cond);
    }
    pthread_mutex_unlock(&l->lock);
}

void RWLock_destory(RWLock* l){
    pthread_mutex_destroy(&l->lock);
}

RWLock rwlock;
int shared_resource = 0;
atomic_int read_count = 0;
atomic_int write_count = 0;

void* rfn(void* arg) {
    int id = *(int*) arg;
    RWLock_startread(&rwlock);
    usleep(100000);
    read_count ++;
    RWLock_doneread(&rwlock);
    return NULL;
}

void* wfn(void* arg) {
    int id = *(int*) arg;
    RWLock_startwrite(&rwlock);
    write_count ++;
    shared_resource++;
    usleep(100000);
    RWLock_donewrite(&rwlock);
    return NULL;
}

int main() {
    RWLock_init(&rwlock);
    pthread_t reader[5], writer[3];
    int reader_ids[5] = {0, 1, 2, 3, 4};
    int writer_ids[3] = {0, 1, 2};

    for (int i = 0; i < 5; i ++){
        pthread_create(&reader[i], NULL, rfn, &reader_ids[i]);
    }

    for (int i = 0; i < 3; i ++){
        pthread_create(&writer[i], NULL, wfn, &writer_ids[i]);
    }

    for(int i = 0;i<5;i++){
        pthread_join(reader[i], NULL);
    }

    for(int i = 0;i<3;i++){
        pthread_join(writer[i], NULL);
    }

    RWLock_destory(&rwlock);

    // 输出最终结果
    printf("Final shared resource value: %d\n", shared_resource);
    printf("Total read operations: %d\n", read_count);
    printf("Total write operations: %d\n", write_count);

    return 0;
}
